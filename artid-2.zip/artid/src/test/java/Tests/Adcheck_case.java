package Tests;

import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;
import Pages.Addcheck;
import Pages.BasePage;
import Pages.HomePage;

public class Adcheck_case extends Basetest{
	HomePage homepage ;
	Addcheck addcheck;
	BasePage BasePage;
	//@DataProvider(name="testdata")
//	public static Object[][] userdata (){return new Object[][] {{},{}}
		//	;}

	@Test(priority =1 )
	public void login() 
	{
		homepage =new HomePage(driver);
	    homepage.login("1111111118","123456","1234");

	 }
	
@Test(priority =2)
	public void addcheck() throws InterruptedException 
	{
	addcheck=new Addcheck(driver);
	addcheck.addcheck(); }

} 
