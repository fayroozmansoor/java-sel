package Tests;

import org.junit.runners.Parameterized.Parameters;
import org.testng.annotations.Test;

import Pages.BasePage;
import Pages.HomePage;

public class login extends Basetest{
	HomePage homepage;
	BasePage BasePage;
	@Parameters
	@Test
	public void login() 
	{
		
//	  homepage =new HomePage(driver);
//	  homepage.login( "1111111118", "123456","1234") ;
	}

}
