package Tests;

import java.io.IOException;

import org.apache.tools.ant.taskdefs.LoadProperties;
import org.junit.runners.Parameterized.Parameters;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

import Pages.BasePage;
import Pages.HomePage;
import data.excel;
import data.loadproperties;

public class loginexcel extends Basetest{
	HomePage homepage;
	BasePage BasePage;
	//username.id,password same shit
	
	@DataProvider(name="ExcelData")
	public Object [][]reg() throws IOException
	{
		//read data from excelreader
		excel ER =new excel();
		return ER.getexcel();
		}

	@Parameters
	@Test(dataProvider ="ExcelData")
	public void login(String username,String password,String code) 
	//public void login() 
	{
		
	  homepage =new HomePage(driver);
	  System.out.printf(username,password,code);
	  homepage.login(username,password,code) ;
	//  homepage.login() ;

	}

}