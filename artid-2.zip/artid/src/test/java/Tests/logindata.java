package Tests;

import org.apache.tools.ant.taskdefs.LoadProperties;
import org.junit.runners.Parameterized.Parameters;
import org.testng.annotations.Test;

import Pages.BasePage;
import Pages.HomePage;
import data.loadproperties;

public class logindata extends Basetest{
	HomePage homepage;
	BasePage BasePage;
	//username.id,password same shit
	
	String username = loadproperties.userData.getProperty("username");
	String password = loadproperties.userData.getProperty("password");
	String code = loadproperties.userData.getProperty("code");


	@Parameters
	@Test
	public void login() 
	{
		
	  homepage =new HomePage(driver);
	  System.out.printf(password);
	  homepage.login( username,password,code) ;
	}

}