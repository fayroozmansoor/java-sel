package data;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;

import org.apache.poi.xssf.eventusermodel.XSSFSheetXMLHandler;
import org.apache.poi.xssf.usermodel.XSSFEvaluationWorkbook;
import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;

public class excel {
	
	static FileInputStream fis=null;
	public   FileInputStream getFileInputStream()
	
	{
		String filepath = "C:\\Users\\admin\\eclipse-workspace\\artid\\src\\test\\java\\data\\Book1.xlsx";
	//String filepath =System.getProperty("user.dir"+"\\src\\test\\java\\data\\Book1.xlsx");
	File srcfile=new File(filepath);
	
	try {
	fis=new FileInputStream(srcfile);}
	catch (FileNotFoundException e) {
    System.out.print("no file");	}
	
	
	return fis ;
	
	}
public Object [][]getexcel() throws IOException

{
	fis=getFileInputStream();
	//TO ENTER THE WORKSHEET AND READ THE CELL
	XSSFWorkbook wb = new XSSFWorkbook(fis);
	XSSFSheet sheet =wb.getSheetAt(0);
	
	int TotalnumoofRows =(sheet.getLastRowNum()+1);
	int TotalnumoofCols =3 ;
	
	
	String [][]	arrayExcelData = new String [TotalnumoofRows][TotalnumoofCols];

	
	for (int i = 0; i < TotalnumoofRows; i++) {
		for (int J = 0; J < TotalnumoofCols; J++) {
			
			XSSFRow row =sheet.getRow(i);
			arrayExcelData[i][J]=row.getCell(J).toString();
			
			  System.out.printf(arrayExcelData[i][J]+"i=  "+  i+"  j=  "+J+"\n");

		}

	}
wb.close();
return arrayExcelData ;
}}