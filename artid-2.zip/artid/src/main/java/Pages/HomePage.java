package Pages;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.Wait;
import org.openqa.selenium.support.ui.WebDriverWait;

public class HomePage extends BasePage {

	public HomePage(WebDriver driver) {
	  super(driver);
}
		
	@FindBy(xpath="//button[contains(text(),'تسجيل ')]")
	WebElement login;
	
	@FindBy(xpath="/html/body/section[2]/div[2]/form[1]/div[1]/input")
	WebElement username;
	
	@FindBy(id="Password")
	WebElement password;
	@FindBy(id="LoginButton")
	WebElement loginbutton;
	@FindBy(id="33809")
	WebElement selectaccount ;
	@FindBy(id="VerificationCode")
	WebElement VerificationCode;
	@FindBy(xpath="//button[contains(text(),'تاكيد')]")
	WebElement confirm ;
	WebDriverWait wait ;
    @FindBy(xpath ="/html/body/div[7]/div[2]/div/div[4]/div[2]/button[2]")
    WebElement agree1;
    @FindBy(id="SickLeaveServicePage")
    WebElement agree2;
    @FindBy (id="li_menu_item_7")
    WebElement services ;
    @FindBy (id="li_menu_Child_34")
    WebElement MWAT ;
    @FindBy(id="ReportCode")
    WebElement code;
    @FindBy(id="btnSearchRequest")
    WebElement search;
    @FindBy(xpath="//button[@onclick=\"AddNewMedicalReportView()\"]")
 //   @FindBy(css="#cardv2 > div:nth-child(1) > div > form > div > button")
  // @FindBy(xpath="//div[@id=“cardv2”]/div/div/form/div/button")
   WebElement Addcheckbtn;
    
    @FindBy(id="iframeAmanatService")
    WebElement pre;
    
public void login(String username1, String password1,String key1) 
	{
	click(login);
	wait = new WebDriverWait(driver, 10);
	wait.until(ExpectedConditions.visibilityOf(username));
	sendkey(username,username1);
	sendkey(password,password1);
	click(loginbutton);	
    wait.until(ExpectedConditions.visibilityOf(selectaccount));
	try {Thread.sleep(3000);} catch (InterruptedException e) {e.printStackTrace();}
	click(selectaccount);	
	wait.until(ExpectedConditions.visibilityOf(VerificationCode));
	sendkey(VerificationCode,key1);

    click(confirm);
	wait.until(ExpectedConditions.visibilityOf(agree1));
	try {Thread.sleep(4000);} catch (InterruptedException e) {e.printStackTrace();}
    click(agree1);
	try {Thread.sleep(3000);} catch (InterruptedException e) {e.printStackTrace();}
    click(agree2);
	wait.until(ExpectedConditions.visibilityOf(services));
    click(services);


}}
