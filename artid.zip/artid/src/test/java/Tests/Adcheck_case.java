package Tests;

import org.testng.annotations.Test;
import Pages.Addcheck;
import Pages.BasePage;
import Pages.HomePage;

public class Adcheck_case extends Basetest{
	HomePage homepage ;
	Addcheck addcheck;
	BasePage BasePage;

	@Test
	public void login() 
	{
		homepage =new HomePage(driver);
	    homepage.login();

	 }
	
@Test
	public void addcheck() 
	{addcheck=new Addcheck(driver);
	 addcheck.addcheck(); }

} 
