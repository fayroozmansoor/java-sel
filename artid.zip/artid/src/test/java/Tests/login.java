package Tests;

import org.testng.annotations.Test;

import Pages.BasePage;
import Pages.HomePage;

public class login extends Basetest{
	HomePage homepage;
	BasePage BasePage;
	@Test
	public void login() 
	{
		
	  homepage =new HomePage(driver);
	  homepage.login();
	}

}
