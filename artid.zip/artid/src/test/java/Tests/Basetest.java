package Tests;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;
import org.openqa.selenium.remote.DesiredCapabilities;
import org.testng.annotations.AfterSuite;
import org.testng.annotations.BeforeSuite;
import org.openqa.selenium.chrome.ChromeOptions;
import org.openqa.selenium.remote.CapabilityType;

public class Basetest {
	public static WebDriver driver ;
@BeforeSuite
public void startdriver() {
	

	System.setProperty("webdriver.chrome.driver", System.getProperty("user.dir")+"/res/chromedriver.exe");
	ChromeOptions capability = new ChromeOptions();
	capability.setCapability(CapabilityType.ACCEPT_SSL_CERTS, true);
	capability.setCapability(CapabilityType.ACCEPT_INSECURE_CERTS,true);
    driver = new ChromeDriver(capability);
	//driver =new ChromeDriver();
    driver.navigate().to("https://sehaportal.t2.sa/");
	//driver.navigate().to("https://10.11.52.34/lean.mwatheq.ui.prod");
	driver.manage().window().maximize();

	
}

@AfterSuite
public void end() 
{driver.quit();}
}
