package Pages;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;

public class Addcheck extends BasePage {
   public Addcheck(WebDriver driver)
{
	super(driver);

	PageFactory.initElements(driver, this);
}

	
    @FindBy(xpath="//button[@onclick=\"AddNewMedicalReportView()\"]")
	WebElement Addcheckbtn;
   // @FindBy(id="iframeAmanatService")
   // WebElement iframeElement;
	 //  @FindBy (id="li_menu_Child_34")
	  // WebElement MWAT ;
    
	public void addcheck()
	{
	System.out.println("hii");
	WebDriverWait wait = null ;
	WebElement MWAT = driver.findElement(By.id("li_menu_Child_34"));
    try {Thread.sleep(5000);} catch (InterruptedException e) {e.printStackTrace();}
	wait.until(ExpectedConditions.visibilityOf(MWAT));
	MWAT.click();
    try {Thread.sleep(5000);} catch (InterruptedException e) {e.printStackTrace();}
	WebElement iframeElement = driver.findElement(By.id("iframeAmanatService"));
	try {Thread.sleep(6000);} catch (InterruptedException e) {e.printStackTrace();}
    wait.until(ExpectedConditions.visibilityOf(iframeElement));
    driver.switchTo().frame(iframeElement);
	Addcheckbtn.click();
	driver.switchTo().defaultContent();}
	}
